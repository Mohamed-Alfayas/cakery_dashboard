import React from 'react'

const Sales = () => {
  return (
    <div>
      
    </div>
  )
}

export default Sales
