import { Button, Grid } from '@mui/material';
import React, { } from 'react'
import "./Home.scss"
import { faEdit } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
const Home = () => {


  // const handleDownload = () => {
  //   fetch('http://localhost:5000/generate-excel')
  //     .then(response => response.blob())
  //     .then(blob => {
  //       const url = window.URL.createObjectURL(blob);
  //       const a = document.createElement('a');
  //       a.href = url;
  //       a.download = 'sample_data.xlsx';
  //       document.body.appendChild(a);
  //       a.click();
  //       a.remove();
  //     })
  //     .catch(error => console.error('Error:', error));
  // };

  return (
    <div>
      <section>

        <Grid container spacing={2}>

          <Grid item xs={6} md={3} sm={3}>
            {/* <Button
              variant="contained"
              color="primary"
              size="small"
              className="me-1"
              style={{
                textTransform: "none",
                borderRadius: "5px",
              }}
              onClick={() => {
                handleDownload()
              }}
            >
              <FontAwesomeIcon icon={faEdit} className="mx-1" />
              Get
            </Button> */}
          </Grid>
          <Grid item xs={6} md={3} sm={3}>

          </Grid>

        </Grid>
      </section>
    </div>
  );
}

export default Home