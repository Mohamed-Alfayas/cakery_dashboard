export const paymentMode = {
  cash: "Cash",
  upi: "UPI",
  debit_card: "Debit Card",
  credit_card: "Credit Card",
  due: "Due",
  cheque: "Cheque",
  net_banking: "Net Banking",
};
