// export const BaseUrl = "http://35.154.61.167:8000/";
// export const LoginUrl = "auth/login/";
// export const CreateMainCategoryUrl = "category/create-main-category/";
// export const GetMainCategoryUrl = "category/get-main-category-data/";
// export const CreateSubCategoryUrl = "category/create-sub-category/";
// export const GetSubCategoryUrl = "category/get-sub-category-data/";
